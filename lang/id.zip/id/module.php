<?php

return [
    'general' => 'Umum',
    'user' => 'Pengguna',
    'todo' => 'Pekerjaan',
    'config' => 'Konfigurasi',
    'role' => 'Peran',
    'permission' => 'Izin',
    'locale' => 'Lokal',
    'media' => 'Media',
    'option' => 'Opsi',
    'utility' => 'Utilitas',
    'modules' => 'Modul',
];
