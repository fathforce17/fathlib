<?php

return [
    'option' => 'Opsi',
    'props' => [
        'type' => 'Tipe',
        'name' => 'Nama',
        'color' => 'Warna',
        'description' => 'Deskripsi',
    ],
];
