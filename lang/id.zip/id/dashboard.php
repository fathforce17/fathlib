<?php

return [
    'dashboard' => 'Beranda',
    'home' => 'Beranda',
    'page_title' => 'Beranda',
    'page_description' => 'Beranda',
    'key_to_search' => ' untuk Mencari',
];
