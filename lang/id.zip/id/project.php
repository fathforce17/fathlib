<?php

return [
    'project' => 'Projek',
    'projects' => 'Projek',
    'props' => [
        'title' => 'Judul',
        'description' => 'Deskripsi',
    ],
];
