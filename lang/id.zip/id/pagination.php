<?php

return [
    'previous' => 'Sebelumnya',
    'next' => 'Berikutnya',
    'showing_result' => 'Menampilkan :from hingga :to dari :total hasil',
    'list_per_page' => ':attribute per halaman',
];
